# Créditos y fuentes

Sprites, XML y audio del paquete **Boruto Ver2 by Vaydra** aportado por el usuario. Video: **Share Sprite Boruto Two Blue Vortex V2 Uzuhiko By VaydraSenki — Char From S-07**. Esta adaptación conserva los dibujos y secuencias del moveset fan del paquete.

Las fuentes originales y sus huellas se conservan en `source_material/BorutoTBV_original/`. Las referencias y datos del video están en `design/boruto_tbv_base/`. Las dos muestras duplicadas de la raíz Audio comparten muestras PCM con sus copias idénticas de BorutoTBv.

Programación de combate, controles, colisiones, daño limitado, captura y liberación del rival para MUGEN: adaptación del proyecto. Los efectos comunes no verbales proceden de los recursos compartidos existentes del proyecto. La entrega usa exclusivamente sprites indexados RLE8, el formato de la versión que se veía en el juego del usuario. Los PNG RGBA originales permanecen intactos como fuentes. Los cuerpos conservan sus píxeles opacos y las zonas translúcidas se dibujan en capas de luz aditivas sincronizadas; estas capas excluyen los píxeles opacos del cuerpo y no tienen colisiones. Los efectos independientes usan AIR A. Ocho recortes de la onda final separan el efecto del cuerpo y suavizan sólo el borde nuevo del recorte. El cuerpo se mantiene en el jugador principal para evitar copias accidentales.
