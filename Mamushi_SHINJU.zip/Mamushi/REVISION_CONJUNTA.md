# Revisión conjunta — 24 de octubre de 2026

Se conserva el conjunto de movimientos y sus entradas. Esta revisión corrige la recepción de golpes, las cadenas de la CPU y la presentación con los recursos completos aportados por el usuario.

Se integran 71 cuadros del paquete completo de Vaydra en las secuencias indicadas en `assets/senki/manifest.json` del proyecto. Se mantienen las ventanas originales de contacto, los costes y los límites de daño de las ultis. Las posiciones del cuerpo se alinean con los sprites originales, separadas del tamaño de los efectos.

El Rinnegan usa tonos claros azul violáceos. Se cambian los píxeles de los iris; se conservan la ropa y los demás colores.

Se añaden cajas de recepción a la animación de daño: los golpes siguientes de un combo ya pueden conectar. La división mantiene las copias autónomas, su resistencia individual y sus límites jugables.

Pruebas realizadas en Ikemen GO con archivos compatibles con MUGEN 1.1. La instalación concreta del usuario y su mando físico requieren comprobación local.
