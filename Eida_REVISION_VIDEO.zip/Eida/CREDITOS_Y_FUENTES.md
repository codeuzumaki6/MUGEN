# Créditos y procedencia

- Sprites de Eida: hoja `Sheet Eida` de Vaydra, recuperada de la captura suministrada por el usuario. Solo se recortó el fondo verde y se empaquetó; no se usaron sprites de la V4 rota.
- Referencia de acabado: GIF de Sumire entregado por el usuario. Sumire no fue copiada ni convertida en Eida.
- Daemon: 16 poses reconstruidas con IA a partir de la hoja de combate y las referencias proporcionadas, con cabello verde, proporciones consistentes y el atuendo rojo de *Two Blue Vortex*.
- Cinemática de Omnipotencia: paneles originales en `manga_referencia_02.png` y `manga_referencia_03.png`, suministrados por el usuario. Solo se recortaron, escalaron y animaron; no se redibujaron con IA.
- Animaciones adicionales de Eida: 16 cuadros creados con IA a partir de la hoja original suministrada, usados únicamente para completar giro, salto, aterrizaje y poses especiales.
- Voz: fragmentos femeninos del archivo japonés `Eida_voz_japonesa_fuente.mp3`. Se excluyeron las intervenciones masculinas atribuidas a Code.
- Base técnica de estados comunes: copia revisada del `common1.cns` del personaje Code funcional suministrado. Los archivos originales de Code no fueron modificados.
- Referencias de jugabilidad: los personajes Tanjiro S3 y Nezuko Advanced Demon Form suministrados por el usuario se analizaron para reproducir cadenas de golpes por pulsaciones, launchers, pausas de impacto y efectos de combate. Seis efectos no verbales de impacto, aparición y guardia proceden del SND de Nezuko. También se extrajeron sus efectos genéricos de energía, chispas, polvo y transición (37 cuadros, con sus ejes originales). El motor colorea la energía en azul mediante PalFX y mezcla aditiva. No se copiaron voces ni sprites del cuerpo de Nezuko. Luffy Gear 5 se revisó como referencia de comandos, desplazamientos y transiciones; no se usaron su cuerpo ni sus voces.
- Programación específica, archivos de personaje y validadores: creados para esta entrega. Los efectos reutilizados tienen su procedencia indicada arriba; los otros efectos no verbales se crearon para Eida.
